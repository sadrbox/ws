// eslint-disable-next-line no-undef, @typescript-eslint/no-var-requires
require("dotenv").config({ path: ".env.loacal" });
