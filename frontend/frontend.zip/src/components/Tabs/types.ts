export type TTabs = {
	id: string;
	label: string;
	active: boolean;
	description: string;
};
