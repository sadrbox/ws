import React, { useState, useEffect, ReactNode, FC } from 'react';
import Counterparties from './index';



const CounterpartiesCreate = () => {
  // const [argState, setArgState] = useState<TArgState | undefined>(undefined)

  return (
    <>
      <div>Counterparties create form</div>
    </>
  );
};

export default CounterpartiesCreate;